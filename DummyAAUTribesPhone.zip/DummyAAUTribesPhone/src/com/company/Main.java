package com.company;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Main {

    public static void main(String[] args) {
        int portNumber = 6666;
        // String hostName = "172.20.10.4";
        String hostName = "127.0.0.1";
        String userInput;

        ResponseListener responseListener;

        try (Socket raspberrySocket = new Socket(hostName, portNumber);
             PrintWriter printWriter = new PrintWriter(raspberrySocket.getOutputStream(), true);
             BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(raspberrySocket.getInputStream()));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
        ){
            responseListener = new ResponseListener(raspberrySocket);
            responseListener.start();

            while ((userInput = stdIn.readLine()) != null) {
                printWriter.println(userInput);
            }
        } catch (Exception e) {
            System.out.println("Error is: " + e);
        }
    }

    public static class ResponseListener extends Thread {
        Socket socket;
        String newResponse;
        public ResponseListener(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));) {
                while ((newResponse = bufferedReader.readLine()) != null) {
                    System.out.println(newResponse);
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }
}
